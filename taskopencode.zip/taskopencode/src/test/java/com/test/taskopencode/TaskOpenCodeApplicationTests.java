package com.test.taskopencode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskOpenCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
