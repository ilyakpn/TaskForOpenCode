package com.test.taskopencode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskOpenCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskOpenCodeApplication.class, args);
	}

}
